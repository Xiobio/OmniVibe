# OmniVibe 品牌与宣传素材

图形名称：**九槽指令环 / Nine-slot Command Ring**。九个固定分段呼应 1–9 任务槽位，中央 `>_` 表达终端操作。墨黑、玉青与少量暖金作为产品识别，独立于各套主题的游戏风格。

[打开素材预览](index.html) · [整套 ZIP](OmniVibe-brand-kit.zip) · [素材总览](brand-overview.png)

## 可直接使用的文件

| 用途 | 文件 | 规格 |
| --- | --- | --- |
| Windows 桌面、EXE 和托盘 | [omnivibe.ico](icons/omnivibe.ico) | 16、20、24、32、40、48、64、128、256 px |
| 立体桌面图标备选 | [omnivibe-premium.ico](icons/omnivibe-premium.ico) | 16–256 px；高分辨率宣传更适用 |
| 透明产品图标 | [立体 PNG](icons/omnivibe-product-3d.png) | 1254×1254，真实 Alpha 透明 |
| 可编辑图形母版 | [标记 SVG](logos/omnivibe-mark.svg) / [应用 SVG](logos/omnivibe-app.svg) | 任意缩放；九个独立分段 |
| 深浅色字标 | [深色 SVG](logos/omnivibe-wordmark-dark.svg) / [浅色 SVG](logos/omnivibe-wordmark-light.svg) | 同目录提供透明 PNG |
| 单色标记 | [白色 SVG](logos/omnivibe-white.svg) / [墨绿 SVG](logos/omnivibe-ink.svg) | 用于单色背景与小尺寸展示 |
| 图标循环动效 | [SVG](motion/omnivibe-loop.svg) / [GIF](motion/omnivibe-loop.gif) / [APNG](motion/omnivibe-loop.apng) / [MP4](motion/omnivibe-loop-1024.mp4) | 4.8 秒无声循环；GIF / APNG 为 512 px，MP4 为 1024 px / 30 fps |
| 发布主视觉 | [1920×1080](promo/launch-cover-1920x1080.png) | 品牌概念画面，非产品截图 |
| README 横幅 | [1600×600](promo/readme-banner-1600x600.png) | 宽幅标题图 |
| 社交分享横图 | [1280×640](promo/social-card-1280x640.png) | 仓库与社交分享封面 |
| 方形发布图 | [1080×1080](promo/social-square-1080.png) | 社交媒体与群聊分享 |
| 产品功能图 | [1920×1080](promo/product-features-1920x1080.png) | 包含原生轮盘组件的示例任务演示 |

`icons/` 中另有 16–1024 px 的透明标记和应用图标 PNG；[尺寸对照](icon-size-proof.png)展示 Windows 常用尺寸在深浅底色上的效果。GIF 已合成墨黑背景以保持边缘平滑；需要透明动效时使用 APNG 或 SVG。MP4 无音轨，不含透明通道。

## 使用约定

- 图标四周保留约图形宽度 12% 的净空，不拉伸，不拆散环段或改变 `>_` 的相对位置。
- 深色底使用标准玉青/白色或白色单色版本；浅色底优先使用墨绿版本。
- 字标 SVG 保留可编辑文字，字体使用 Windows 自带 Segoe UI / Bahnschrift 及通用后备字体；没有捆绑字体。跨平台展示优先用已导出的透明 PNG。
- 动效中的固定环段不旋转、不交换位置，仅改变高亮；它是品牌动效，不表示真实任务状态。SVG 遵循减少动态效果偏好。
- 宣传文字使用已实现的固定槽位、快捷切换、任务轮盘、hooks 状态接入和主题能力。社区自定义皮肤和许可证发布状态以项目 README 为准，不用素材表达已完成尚未上线的能力。
- 当前为开发预览版，发布图保留对应标识。

## 源文件与复现

平面图形由 [build-brand-icons.py](../../tools/build-brand-icons.py)确定性生成，SVG 是可编辑母版；立体产品图标和品牌主视觉使用**内置 imagegen**，独立保存源图及实际提示词：

- [立体产品图标源图](source/product-icon-3d.png) · [实际提示词](source/product-icon-3d.prompt.md)
- [品牌主视觉源图](source/brand-keyvisual.png) · [实际提示词](source/brand-keyvisual.prompt.md)

```powershell
python tools/build-brand-icons.py
python tools/build-brand-kit.py
```

需要 Pillow、numpy、imageio-ffmpeg。图形、排版、尺寸导出和动效由本地工具构建，实际产品组件演示来自 `docs/weapon-loadout/screens/radial.png`。构建器会解码 GIF/APNG/MP4、检查 ICO 尺寸并导出资源清单；源图已保存在仓库，复现不需要重新调用 imagegen。

程序已引用 `icons/omnivibe.ico` 作为 EXE 图标，并把同一图标嵌入程序集供系统托盘使用。图标接入已编译和解码验证；现有运行实例保留，下一次使用 `run.ps1` 正常构建启动时采用新图标。宣传动效不会作为常驻动画加载进程序。
